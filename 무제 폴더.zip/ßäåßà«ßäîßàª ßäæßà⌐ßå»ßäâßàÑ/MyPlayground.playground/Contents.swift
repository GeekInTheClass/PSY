var array = [1, 4, 5, 2, 9, 8, 7, 10, 6]
var array2: [Int] = []

var i:Int = 0

for item in array {
    if item % 2 == 0{
        array2.append(item * item)
    }
    else {
        array2.append(item * 2)
    }
}

print(array2)


